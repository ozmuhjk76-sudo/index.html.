# موقع بطاقات الشراء الترفيهية وشحن الألعاب والتطبيقات 🎮⚡

مشروع موقع ويب متكامل وتفاعلي لشحن **54 لعبة وتطبيق وبطاقة رقمية** مطابق تماماً للتصميم المرفق ومجهّز للنشر المباشر عبر **GitHub** و **Vercel**.

---

## الأقسام والتطبيقات المتوفرة في الموقع (54 تطبيق ولعبة)

1. **قسم الألعاب (34 لعبة):**
   - شدات بوبجي، فري فاير FREE FIRE، موبايل ليجند، xbox، كلاش اوف رويال، كلاش اوف كلانس، مواسم بوبجي، لعبة APEX، لعبة ROBLOX، لوردس موبايل، براول استارز، بوم بتش، انتقام السلاطين، بطائق فورتنايت، بطاقات بلاي ستيشن، ماين كرافت، بلود سترايك - BLOOD STRIKE، FARLIGHT 84، هاي داي - Hay Day، يلا لودوا - Yalla Ludo، Last War: Survival (NEW)، ملوك البقاء (NEW)، النجاة في الصقيع (NEW)، Ludo Club لودو كلوب (NEW)، Ludo World (NEW)، Arena Breakout (NEW)، Delta Force (NEW)، eFootball (NEW)، Ball Pool 8 (NEW)، Top War: Battle Game (NEW)، King of Avalon (NEW)، War Robots (NEW)، Genshin Impact (NEW)، Honor of Kings (NEW).
2. **قسم بطاقات الشراء عبر الإنترنت (3 بطاقات):**
   - رايزر جولد، ابل كارد، بطائق ماستركارد.
3. **قسم خدمات الترفيه (3 خدمات):**
   - اشتراك HydraTV، شاهد VIP، سيرفر نوفا.
4. **قسم الشات (12 تطبيق):**
   - اهلا شات، كونزات يو يو، كونزات يوهو، بيجو لايف، لايكي لايف، توب توب، عملات تيكتوك، الماس ايمو لايف، بارتي ستار، كفو - Kafu، Saya (NEW)، جواكر (NEW).
5. **قسم برامج الكمبيوتر (برنامجان):**
   - ترخيص ويندوز 10، ترخيص ويندوز 11.

---

## خطوات رفع الكود على GitHub وتشغيله على Vercel 🚀

### الخطوة 1: رفع الملفات إلى GitHub
1. ادخل إلى حسابك على [GitHub](https://github.com) واضغط على **New repository**.
2. اكتب اسم المستودع مثلاً: `topup-store` ثم اضغط **Create repository**.
3. اضغط على **uploading an existing file** وقم برفع الملفات الموجودة في هذا المجلد:
   - `index.html`
   - `vercel.json`
   - `package.json`
   - `README.md`
4. اضغط على الزر الأخضر **Commit changes**.

*(أو باستخدام أوامر Git في الطرفية Terminal)*:
```bash
git init
git add .
git commit -m "Initial commit: Top-up Store"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/topup-store.git
git push -u origin main
```

### الخطوة 2: ربط المستودع وتشغيل الموقع على Vercel
1. ادخل إلى موقع [Vercel](https://vercel.com) وسجّل الدخول بحسابك في **GitHub**.
2. اضغط على **Add New...** ثم اختر **Project**.
3. ستظهر لك قائمة مستودعاتك في GitHub؛ اختر مستودع `topup-store` واضغط **Import**.
4. اترك الإعدادات الافتراضية كما هي واضغط **Deploy**.
5. خلال ثوانٍ قليلة سيعمل موقعك على رابط رسمي مجاني مثل:
   `https://topup-store.vercel.app`
